package es.urjc.code.juegosenred;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestEjer1ConUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestEjer1ConUiApplication.class, args);
	}
}
